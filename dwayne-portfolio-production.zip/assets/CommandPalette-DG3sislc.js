import{r as s,j as o}from"./three-DvYEC7Hr.js";import{u as w}from"./index-BTDRdjBs.js";import{m as c}from"./motion-DrkPli85.js";import"./vendor-gH-7aFTg.js";const E=()=>{const[i,d]=s.useState(""),{toggleCommandPalette:a,toggleSound:m,toggleTerminal:p,toggleDarkMode:u,toggleGame:g,isDarkMode:r,gameActive:b}=w(),h=[{id:"download",label:"Download Resume (TXT)",icon:"📄",action:()=>{const e=`
DWAYNE CONCEPCION
Aspiring Developer with Irreplaceable Perspective
Email: dwaynecon@me.com | Location: Decatur, IL

SUMMARY
I'm not your typical entry-level developer. I bring a CS degree, 8 years of hands-on 
experience supporting people with disabilities, and a deep understanding of how technology 
fails its most vulnerable users. I'm learning to code not just to build things, but to 
solve problems I've personally witnessed.

TECHNICAL SKILLS
• Frontend: JavaScript (ES6+), React, Three.js, HTML/CSS, Swift
• Backend: Node.js, Python, MongoDB, SQL, Express
• AI/3D: TensorFlow.js, Electron, SVG Generation, Firebase
• DevOps: Git, Linux, Docker, Bash

FEATURED PROJECTS
• Aritrova - AI-powered 3D dollhouse design platform with automated laser cutting
• Grocery Planner AI - Intelligent meal planning with constraint-based optimization
• iOS Textbook Exchange - Student marketplace with Firebase backend

EXPERIENCE
Information Services Specialist II | State of Illinois - DoIT @ DCFS | Nov 2021 – Mar 2025
Foster Care Caseworker | Kemmerer Village | Mar 2019 – Mar 2021
Professional Caregiver | Private Contract | Sept 2015 – Jul 2017
Direct Support Specialist | Transitional Services Inc. | 2012 – 2015

Hire me for the insights. Train me on the code. 
Together, we'll build technology that works for everyone.
    `,n=new Blob([e],{type:"text/plain"}),l=URL.createObjectURL(n),t=document.createElement("a");t.href=l,t.download="Dwayne_Concepcion_Resume.txt",document.body.appendChild(t),t.click(),document.body.removeChild(t),URL.revokeObjectURL(l)}},{id:"resume-pdf",label:"View Resume (PDF)",icon:"📋",action:()=>window.open("/resume.pdf","_blank")},{id:"source",label:"View Source",icon:"👨‍💻",action:()=>window.open("https://github.com/dwaynecon/dwayne-portfolio","_blank")},{id:"theme",label:r?"Light Mode":"Dark Mode",icon:r?"☀️":"🌙",action:u},{id:"sound",label:"Toggle Sound",icon:"🔊",action:m},{id:"terminal",label:"Open Terminal",icon:"💻",action:p},{id:"game",label:b?"Stop Game":"Start Game",icon:"🎮",action:g}].filter(e=>e.label.toLowerCase().includes(i.toLowerCase()));return s.useEffect(()=>{const e=n=>{n.key==="Escape"&&a()};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[a]),o.jsx(c.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:"fixed inset-0 z-50 flex items-start justify-center pt-32 bg-black bg-opacity-50 backdrop-blur-sm",onClick:a,children:o.jsxs(c.div,{initial:{scale:.9,y:-20},animate:{scale:1,y:0},exit:{scale:.9,y:-20},className:"glass-morphism rounded-2xl p-2 w-full max-w-2xl",onClick:e=>e.stopPropagation(),children:[o.jsx("input",{type:"text",value:i,onChange:e=>d(e.target.value),placeholder:"Type a command or search...",className:"w-full px-4 py-3 bg-transparent border-b border-gray-700 outline-none text-lg",autoFocus:!0}),o.jsx("div",{className:"mt-2 max-h-96 overflow-y-auto",children:h.map(e=>o.jsxs("button",{onClick:()=>{e.action(),a()},className:"w-full px-4 py-3 text-left hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center gap-3 transition-colors",children:[o.jsx("span",{className:"text-2xl",children:e.icon}),o.jsx("span",{children:e.label})]},e.id))})]})})};export{E as default};
