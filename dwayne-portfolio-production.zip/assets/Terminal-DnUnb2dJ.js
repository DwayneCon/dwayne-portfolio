import{r as a,j as o}from"./three-DvYEC7Hr.js";import{u as f}from"./index-BTDRdjBs.js";import{m as u}from"./motion-DrkPli85.js";import"./vendor-gH-7aFTg.js";const w=()=>{const[s,l]=a.useState(""),[c,m]=a.useState([`Welcome to Dwayne's Terminal! Type "help" for commands.`]),p=a.useRef(null),{toggleTerminal:d}=f(),i={help:()=>`Available commands: ls, cd, cat, about, skills, projects, experience, contact, whoami, pwd, date, uptime, clear, exit
Easter eggs: Try "konami", "matrix", or "sudo rm -rf /"`,ls:()=>"projects/  skills/  experience/  contact.txt  README.md  portfolio.json",pwd:()=>"/home/dwayne/portfolio",whoami:()=>"dwayne",cd:()=>`Usage: cd [directory]
Available: projects, skills, experience, home`,"cd projects":()=>'Changed to projects directory. Use "ls" to see available projects.',"cd skills":()=>'Changed to skills directory. Use "ls" to see technical skills.',"cd experience":()=>'Changed to experience directory. Use "ls" to see work history.',"cd home":()=>"Changed to home directory.","cd ~":()=>"Changed to home directory.","cd ..":()=>"Moved up one directory.","cat contact.txt":()=>`Email: dwaynecon@me.com
Location: Decatur, IL
GitHub: github.com/yourusername
Portfolio: https://dwayne-portfolio.vercel.app`,"cat README.md":()=>`# Dwayne Concepcion Portfolio

Aspiring Developer with Irreplaceable Perspective

Interactive portfolio showcasing projects, skills, and experience.
Built with React, Three.js, and modern web technologies.`,"cat portfolio.json":()=>`{
  "name": "Dwayne Concepcion",
  "role": "Aspiring Developer",
  "specialization": "Accessibility & Human-Centered Design",
  "experience": "8+ years supporting people with disabilities",
  "skills": ["JavaScript", "React", "Three.js", "Python", "Node.js"]
}`,about:()=>`Dwayne Concepcion
Aspiring Developer with Irreplaceable Perspective

CS degree + 8 years supporting people with disabilities.
Building technology that works for everyone, not just ideal users.`,contact:()=>`Email: dwaynecon@me.com
Location: Decatur, IL
Portfolio: Interactive portfolio with 3D elements
Specialty: Accessibility-focused development`,skills:()=>`Frontend: JavaScript (ES6+), React, Three.js, HTML/CSS, Swift
Backend: Node.js, Python, MongoDB, SQL, Express
AI/3D: TensorFlow.js, Electron, SVG Generation
DevOps: Git, Linux, Docker, Bash`,projects:()=>`1. Aritrova - AI-powered 3D dollhouse platform with laser cutting
2. Grocery Planner AI - Constraint-based meal planning optimization
3. Interactive Portfolio - This 3D portfolio with games and easter eggs
4. iOS Textbook Exchange - Student marketplace with Firebase`,experience:()=>`Information Services Specialist II | State of Illinois (2021-2025)
Foster Care Caseworker | Kemmerer Village (2019-2021)
Professional Caregiver | Private Contract (2015-2017)
Direct Support Specialist | Transitional Services (2012-2015)`,clear:()=>(m([`Welcome to Dwayne's Terminal! Type "help" for commands.`]),""),exit:()=>(d(),"Goodbye!")},h=()=>{const e=s.trim().toLowerCase();if(!e)return;let t="";if(i[e])t=i[e]();else if(e.startsWith("cd ")){const n=e.slice(3).trim(),r=`cd ${n}`;i[r]?t=i[r]():t=`cd: ${n}: No such directory
Available: projects, skills, experience, home`}else if(e.startsWith("cat ")){const n=e.slice(4).trim(),r=`cat ${n}`;i[r]?t=i[r]():t=`cat: ${n}: No such file
Available files: contact.txt, README.md, portfolio.json`}else e==="sudo rm -rf /"?t="Nice try! 😄 This is a portfolio, not a real terminal.":e.includes("hack")||e.includes("exploit")?t='I see you have a sense of humor! Try "konami" instead.':e==="konami"?t="Try the Konami code: ↑↑↓↓←→←→BA (on the main page)":e==="matrix"?t="Wake up, Neo... Try Ctrl+K for the command palette!":e==="hello"||e==="hi"?t='Hello! Welcome to my terminal. Type "help" for available commands.':e==="date"?t=new Date().toString():e==="uptime"?t="Portfolio has been running since you loaded the page!":t=`Command not found: ${s.trim()}
Type "help" for available commands.`;m([...c,`$ ${s.trim()}`,t].filter(Boolean)),l("")};return a.useEffect(()=>{p.current?.focus()},[]),o.jsxs(u.div,{initial:{opacity:0,y:100},animate:{opacity:1,y:0},exit:{opacity:0,y:100},className:"fixed bottom-0 left-0 right-0 z-50 h-96 bg-black bg-opacity-95 border-t-2 border-green-500 p-4 font-jetbrains",children:[o.jsxs("div",{className:"flex justify-between items-center mb-4",children:[o.jsx("span",{className:"text-green-400",children:"dwayne@portfolio:~$"}),o.jsx("button",{onClick:d,className:"text-red-500 hover:text-red-400",children:"✕"})]}),o.jsx("div",{className:"h-72 overflow-y-auto mb-2 text-green-400 text-sm",children:c.map((e,t)=>o.jsx("div",{className:"mb-1",children:e},t))}),o.jsxs("div",{className:"flex items-center text-green-400",children:[o.jsx("span",{className:"mr-2",children:"$"}),o.jsx("input",{ref:p,type:"text",value:s,onChange:e=>l(e.target.value),onKeyDown:e=>e.key==="Enter"&&h(),className:"flex-1 bg-transparent outline-none"})]})]})};export{w as default};
